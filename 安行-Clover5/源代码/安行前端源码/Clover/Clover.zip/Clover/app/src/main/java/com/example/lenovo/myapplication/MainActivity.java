package com.example.lenovo.myapplication;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity{
    EditText userID,temperature,weight,heartbeat,bloodPressure,bloodFat;
    Button insert,findAll,findLast,show;
    User user=null;
    Context mContext;
    Upload upload;
    private SQLiteDatabase db;
    private UserDBhelper myDBHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        userID = (EditText) findViewById(R.id.userID);
        temperature = (EditText) findViewById(R.id.temperature);
        weight = (EditText) findViewById(R.id.weight);
        heartbeat = (EditText) findViewById(R.id.heartbeat);
        bloodPressure = (EditText) findViewById(R.id.bloodPressure);
        bloodFat = (EditText) findViewById(R.id.bloodFat);
        insert= (Button) findViewById(R.id.insert);
        findAll= (Button) findViewById(R.id.findAll);
        findLast= (Button) findViewById(R.id.findLast);
        show= (Button) findViewById(R.id.show);
        mContext=MainActivity.this;
        myDBHelper = new UserDBhelper(mContext, "Clover", null, 1);

        insert.setOnClickListener(new insertOnClick());
        findAll.setOnClickListener(new findAllOnClick());
        findLast.setOnClickListener(new findLastOnClick());
        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                startActivity(intent);
            }
        });
        upload = new Upload(mContext,user);
    }
    class insertOnClick implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            user=new User(userID.getText().toString(),temperature.getText().toString(),weight.getText().toString(),heartbeat.getText().toString(),bloodPressure.getText().toString(),bloodFat.getText().toString());
            upload.insert(user);
        }
    }

    private class findAllOnClick implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            StringBuilder sb= new StringBuilder();
            db=myDBHelper.getReadableDatabase();
            //指定查询结果的排序方式
            Cursor cursor = db.query("user", null, null, null, null, null, null);
            if (cursor.moveToFirst()) {
                do {
                    String userID = cursor.getString(cursor.getColumnIndex("userID"));
                    String temperature = cursor.getString(cursor.getColumnIndex("temperature"));
                    String weight = cursor.getString(cursor.getColumnIndex("weight"));
                    String heartbeat = cursor.getString(cursor.getColumnIndex("heartbeat"));
                    String bloodPressure = cursor.getString(cursor.getColumnIndex("bloodPressure"));
                    String bloodFat = cursor.getString(cursor.getColumnIndex("bloodFat"));
                    String dateTime = cursor.getString(cursor.getColumnIndex("dateTime"));
                    sb.append("userID：" + userID +
                            " temperature：" + temperature +
                            " weight：" + weight +
                            " heartbeat：" + heartbeat +
                            " bloodPressure：" + bloodPressure +
                            " bloodFat：" + bloodFat +
                            " dateTime：" + dateTime +
                            "\n\n");
                } while (cursor.moveToNext());
            }
            cursor.close();
            Toast.makeText(mContext, sb.toString(), Toast.LENGTH_SHORT).show();
//            Upload upload = new Upload(mContext,user);
//            StringBuilder sb = upload.findAll();
//            Toast.makeText(mContext, sb.toString(), Toast.LENGTH_SHORT).show();
        }
    }

    private class findLastOnClick implements View.OnClickListener {
        @Override
        public void onClick(View v) {
//            Upload upload = new Upload(mContext,user);
            String dateTime = null;
            user=new User();
            db=myDBHelper.getReadableDatabase();
            Cursor cursor = db.query("user", null, null, null, null, null, null);
            if (cursor.moveToFirst()) {
                do {
                    user.setUserID(cursor.getString(cursor.getColumnIndex("userID")));
                    user.setTemperature(cursor.getString(cursor.getColumnIndex("temperature")));
                    user.setWeight(cursor.getString(cursor.getColumnIndex("weight")));
                    user.setHeartbeat(cursor.getString(cursor.getColumnIndex("heartbeat")));
                    user.setBloodPressure(cursor.getString(cursor.getColumnIndex("bloodPressure")));
                    user.setBloodFat(cursor.getString(cursor.getColumnIndex("bloodFat")));
                    dateTime = cursor.getString(cursor.getColumnIndex("dateTime"));
                } while (cursor.moveToNext());
            }
            cursor.close();
            //user = upload.findLast();
            Toast.makeText(mContext,"userID：" + user.getUserID() +
                    " temperature：" + user.getTemperature() +
                    " weight：" + user.getWeight() +
                    " heartbeat：" + user.getHeartbeat() +
                    " bloodPressure：" + user.getBloodPressure() +
                    " bloodFat：" + user.getBloodFat() +
                    " dateTime：" + dateTime, Toast.LENGTH_SHORT).show();
//            userID.setText(user.getUserID());
//            temperature.setText(user.getTemperature());
//            weight.setText(user.getWeight());
//            heartbeat.setText(user.getHeartbeat());
//            bloodPressure.setText(user.getBloodPressure());
//            bloodFat.setText(user.getBloodFat());
        }
    }
}

