package com.example.lenovo.myapplication;

/**
 * Created by Lenovo on 2018/6/3.
 */

public class User {
    private String userID;
    private String temperature;
    private String weight;
    private String heartbeat;
    private String bloodPressure;
    private String bloodFat;

    public User(){
        userID=null;
        temperature=null;
        weight=null;
        heartbeat=null;
        bloodPressure=null;
        bloodFat=null;
    }

    public User(String userID,String temperature,String weight,String heartbeat,String bloodPressure,String bloodFat){
        this.userID=userID;
        this.temperature=temperature;
        this.weight=weight;
        this.heartbeat=heartbeat;
        this.bloodPressure=bloodPressure;
        this.bloodFat=bloodFat;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getHeartbeat() {
        return heartbeat;
    }

    public void setHeartbeat(String heartbeat) {
        this.heartbeat = heartbeat;
    }

    public String getBloodPressure() {
        return bloodPressure;
    }

    public void setBloodPressure(String bloodPressure) {
        this.bloodPressure = bloodPressure;
    }

    public String getBloodFat() {
        return bloodFat;
    }

    public void setBloodFat(String bloodFat) {
        this.bloodFat = bloodFat;
    }


}