package com.example.linecharttest;

import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.widget.ImageView;
import java.util.Vector;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.Bitmap.Config;
import android.graphics.Paint.FontMetrics;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.BarChart;

public class MainActivity extends AppCompatActivity {

    private GraphicalView lChart;
    private ChartDrawing lineChart;
    private String[] mMonth = new String[] { "Jan", "Feb", "Mar", "Apr", "May",
            "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",

    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int[] income = { 1000, 3700, 3800, 2000, 2500, 6000, 1000, 8000, 9000,
                5000, 2000 };
        lineChart = new ChartDrawing("Amount in Dollars", "Year 2013",
                "Test Chart", mMonth);
        lineChart.set_XYSeries(income, "income");
        lineChart.set_XYMultipleSeriesRenderer_Style(lineChart
                .set_XYSeriesRender_Style());
        LinearLayout lineChartContainer = (LinearLayout) findViewById(R.id.lineChart_container);
        // Creating a Line Chart
        lChart = (GraphicalView) ChartFactory.getLineChartView(
                getBaseContext(), lineChart.getDataset(),
                lineChart.getMultiRenderer());

        // Adding the Line Chart to the LinearLayout
        lineChartContainer.addView(lChart);




    }


}